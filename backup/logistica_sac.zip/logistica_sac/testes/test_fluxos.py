# -*- coding: utf-8 -*-
"""Fluxos principais do sistema, com Tkinter real: cadastrar, editar, agendar,
resolver, buscar, atalhos de tratativa, desfazer, relatorio e tela Sobre."""

import unittest
from unittest import mock

import tkinter as tk

from testes.base import BaseTela
from nucleo import database as db
from nucleo import registro_erros
from nucleo import tratativas_rapidas


class TestCadastro(BaseTela):
    def test_cadastrar_nota_e_aparece_na_lista(self):
        self.cadastrar(100, "ACME", "REENTREGA")
        nota = self.nota_por_nf(100, "ACME")
        self.assertIsNotNone(nota)
        self.assertIn(nota["id"], self.app.blocos)

    def test_duplicada_pendente_bloqueia_mas_resolvida_nao(self):
        self.cadastrar(101, "ACME", "REENTREGA")
        self.cadastrar(101, "ACME", "REENTREGA")
        self.assertTrue(self.erros and "pendente" in self.erros[-1])
        self.assertEqual(len([n for n in db.listar_notas_ativas() if n["nf_numero"] == 101]), 1)
        db.marcar_resolvida(self.nota_por_nf(101)["id"])
        self.cadastrar(101, "ACME", "REENTREGA")
        self.assertIsNotNone(self.nota_por_nf(101, "ACME"))

    def test_cadastro_com_agendamento_pede_data_e_valida(self):
        self.cadastrar(102, "ACME", "AGENDAMENTO", data_agendamento="01012020")
        self.assertIsNone(self.nota_por_nf(102))           # data passada: nao cadastra
        self.cadastrar(102, "ACME", "AGENDAMENTO", data_agendamento="25122030")
        self.assertEqual(self.nota_por_nf(102)["agendamento_data"], "25122030")


class TestEdicao(BaseTela):
    def setUp(self):
        super().setUp()
        db.adicionar_cliente("ACME")
        db.adicionar_cliente("BETA LTDA")
        self.cadastrar(200, "ACME", "REENTREGA")
        self.nota_id = self.nota_por_nf(200)["id"]

    def test_editar_remetente_com_sugestao(self):
        self.escolher_na_busca("bet")
        self.app.editar_campo(self.nota_id, "cliente", "Remetente")
        self.assertEqual(db.obter_nota(self.nota_id)["cliente"], "BETA LTDA")

    def test_editar_remetente_novo_e_cadastrado(self):
        self.escolher_na_busca("GAMMA SA")
        self.app.editar_campo(self.nota_id, "cliente", "Remetente")
        self.assertEqual(db.obter_nota(self.nota_id)["cliente"], "GAMMA SA")
        self.assertIn("GAMMA SA", db.listar_clientes())

    def test_editar_ocorrencia_para_agendamento_pede_data(self):
        antes = dict(db.obter_nota(self.nota_id))
        self.respostas_data.append("25122030")
        self.escolher_na_busca("agen")
        self.app.editar_ocorrencia(self.nota_id)
        nota = db.obter_nota(self.nota_id)
        self.assertEqual((nota["ocorrencia"], nota["agendamento_data"]), ("AGENDAMENTO", "25122030"))
        for campo in ("nf_numero", "cliente", "sigla", "data_ocorrencia", "criado_em", "observacao"):
            self.assertEqual(nota[campo], antes[campo])

    def test_data_invalida_ou_cancelada_nao_altera(self):
        for resposta in ("01012020", "xx", None):
            self.respostas_data.append(resposta)
            self.escolher_na_busca("agen")
            self.app.editar_ocorrencia(self.nota_id)
            self.assertEqual(db.obter_nota(self.nota_id)["ocorrencia"], "REENTREGA")

    def test_editar_data_do_agendamento_e_sair_dele(self):
        self.respostas_data.append("25122030")
        self.escolher_na_busca("agen")
        self.app.editar_ocorrencia(self.nota_id)
        self.respostas_data.append("26122030")
        self.app.editar_data_agendamento(self.nota_id)
        self.assertEqual(db.obter_nota(self.nota_id)["agendamento_data"], "26122030")
        self.escolher_na_busca("reentrega")
        self.app.editar_ocorrencia(self.nota_id)
        self.assertIsNone(db.obter_nota(self.nota_id)["agendamento_data"])

    def test_item_de_menu_so_aparece_quando_agendamento(self):
        self.respostas_data.append("25122030")
        self.escolher_na_busca("agen")
        self.app.editar_ocorrencia(self.nota_id)
        capturados = []
        with mock.patch.object(tk.Menu, "tk_popup", lambda self_, x, y: capturados.append(self_)):
            bloco = self.app.blocos[self.nota_id]
            bloco._abrir_menu(mock.Mock(x_root=0, y_root=0))
            menu = capturados[-1]
            rotulos = [menu.entrycget(i, "label") for i in range(menu.index("end") + 1)
                       if menu.type(i) == "command"]
        self.assertIn("Alterar data do agendamento", rotulos)

    def test_falha_de_banco_mostra_erro_e_nao_altera(self):
        import sqlite3
        with mock.patch.object(db, "atualizar_ocorrencia",
                               side_effect=sqlite3.OperationalError("disco cheio")):
            self.escolher_na_busca("prio")
            self.app.editar_ocorrencia(self.nota_id)
        self.assertTrue(any("Falha ao salvar" in e for e in self.erros))
        self.assertEqual(db.obter_nota(self.nota_id)["ocorrencia"], "REENTREGA")


class TestTratativaAtalhos(BaseTela):
    def test_funcao_expandir(self):
        for entrada, saida in (("e", "tratando via e-mail"), ("E", "tratando via e-mail"),
                               ("w", "tratando via WhatsApp"), ("W", "tratando via WhatsApp"),
                               ("s", "informacoes em sistema"), (" S ", "informacoes em sistema"),
                               ("ex", "ex"), ("e mail", "e mail"), ("", ""), ("x", "x")):
            self.assertEqual(tratativas_rapidas.expandir_atalho(entrada), saida)

    def test_nova_atualizacao_grava_frase(self):
        self.cadastrar(300, "ACME", "REENTREGA")
        nota_id = self.nota_por_nf(300)["id"]
        for letra, esperado in (("e", "TRATANDO VIA E-MAIL"), ("W", "TRATANDO VIA WHATSAPP"),
                                ("s", "INFORMACOES EM SISTEMA"), ("contato feito", "CONTATO FEITO")):
            with mock.patch("interface.nota_block.pedir_texto_atualizacao", lambda *a, **k: letra):
                self.app.blocos[nota_id]._adicionar_tratativa()
            textos = [t["texto"] for t in db.listar_tratativas(nota_id)]
            self.assertEqual(textos[-1], esperado)


class TestResolverBuscaDesfazer(BaseTela):
    def setUp(self):
        super().setUp()
        self.cadastrar(400, "ACME", "REENTREGA")
        self.cadastrar(401, "BETA", "REENTREGA")
        self.id400 = self.nota_por_nf(400)["id"]

    def _resolver(self, id_nota, morosidade="cliente"):
        nota = db.obter_nota(id_nota)
        resultado = {"nf_numero": nota["nf_numero"], "cliente": nota["cliente"],
                     "ocorrencia": nota["ocorrencia"], "sigla": nota["sigla"],
                     "dias": 3, "horas": 5, "morosidade": morosidade}
        with mock.patch("interface.edicao_notas.fluxo_marcar_resolvido", lambda *a, **k: resultado):
            self.app.marcar_como_resolvido(id_nota)

    def test_resolver_vai_para_historico(self):
        self._resolver(self.id400)
        self.assertIsNone(self.nota_por_nf(400))
        self.assertEqual(len(db.buscar_historico_por_nf(400)), 1)

    def test_buscar_por_nf(self):
        self.app.var_busca.set("401")
        self.app._executar_busca()
        bloco = self.app.blocos[self.nota_por_nf(401)["id"]]
        self.assertEqual(str(bloco.txt_cabecalho.cget("background")), "#fff2a8")  # nota destacada
        self.assertNotEqual(str(self.app.blocos[self.id400].txt_cabecalho.cget("background")), "#fff2a8")

    def test_buscar_nf_repetida_mostra_todas(self):
        self.cadastrar(400, "OUTRO", "REENTREGA")
        self.app.var_busca.set("400")
        self.app._executar_busca()
        self.app.update()
        self.assertEqual(len(self.app.blocos), 2)

    def test_desfazer_edicao_e_resolucao(self):
        self.escolher_na_busca("prio")
        self.app.editar_ocorrencia(self.id400)
        self.assertEqual(db.obter_nota(self.id400)["ocorrencia"], "PRIORIZAR ENTREGA")
        self.app.desfazer_ultima_alteracao()
        self.assertEqual(db.obter_nota(self.id400)["ocorrencia"], "REENTREGA")

        self._resolver(self.id400)
        self.app.desfazer_ultima_alteracao()
        self.assertIsNotNone(self.nota_por_nf(400))
        self.assertEqual(db.buscar_historico_por_nf(400), [])
        self.assertIn(self.id400, self.app.blocos)

    def test_desfazer_sem_nada_nao_quebra(self):
        self.app.desfazer_ultima_alteracao()

    def test_desfazer_limpeza_do_historico_e_remocao_de_cadastro(self):
        self._resolver(self.id400)
        self.app._registrar_desfazer_cadastro("remetente", "ZZZ", db.adicionar_cliente)
        self.app.desfazer_ultima_alteracao()
        self.assertIn("ZZZ", db.listar_clientes())
        registros = list(db.listar_historico())
        db.limpar_historico_manual()
        from nucleo import database
        self.app.pilha_desfazer.registrar("limpeza", lambda: database.restaurar_historico(registros))
        self.app.desfazer_ultima_alteracao()
        self.assertEqual(len(db.listar_historico()), 1)

    def test_ctrl_z_na_janela_principal(self):
        self.escolher_na_busca("prio")
        self.app.editar_ocorrencia(self.id400)
        self.app.focus_force()
        self.app.event_generate("<Control-z>")
        self.app.update()
        self.assertEqual(db.obter_nota(self.id400)["ocorrencia"], "REENTREGA")


class TestAtalhosGlobais(BaseTela):
    def _tecla(self, sequencia):
        self.app.update()
        self.app.focus_force()
        self.app.update()
        self.app.event_generate(sequencia)
        self.app.update()

    def test_ctrl_n_limpa_formulario_e_foca_nf(self):
        self.app.var_nf.set("123")
        self.app.var_cliente.set("ACME")
        self.app.entry_busca.focus_force()
        self.app.update()
        self.app.entry_busca.event_generate("<Control-n>")
        self.app.update()
        self.assertEqual((self.app.var_nf.get(), self.app.var_cliente.get()), ("", ""))
        self.assertIs(self.app.focus_get(), self.app.entry_nf)

    def test_ctrl_f_foca_busca(self):
        self.app.entry_nf.focus_force()
        self.app.update()
        self.app.entry_nf.event_generate("<Control-f>")
        self.app.update()
        self.assertIs(self.app.focus_get(), self.app.entry_busca)

    def test_f5_recarrega_lista_com_dados_novos(self):
        self.assertEqual(len(self.app.blocos), 0)
        db.inserir_nota(900, "ACME", "REENTREGA", "SP", "16102026", None)  # entrou por fora da tela
        self._tecla("<F5>")
        self.assertEqual(len(self.app.blocos), 1)

    def test_atalhos_listados_no_menu_editar(self):
        barra = self.app.nametowidget(self.app.cget("menu"))
        indice = [i for i in range(barra.index("end") + 1)
                  if barra.type(i) == "cascade" and barra.entrycget(i, "label") == "Editar"][0]
        menu = self.app.nametowidget(barra.entrycget(indice, "menu"))
        acel = [menu.entrycget(i, "accelerator") for i in range(menu.index("end") + 1)
                if menu.type(i) == "command"]
        self.assertEqual(acel, ["Ctrl+Z", "Ctrl+N", "Ctrl+F", "F5"])


class TestRelatorioSobreErros(BaseTela):
    def test_cliente_moroso_clicavel(self):
        db.inserir_historico(1, "CLIENTE LENTO", "REENTREGA", "SP", 5, 2, "cliente")
        db.inserir_historico(2, "CLIENTE LENTO", "REENTREGA", "RJ", 9, 0, "cliente")
        db.inserir_historico(3, "CLIENTE LENTO", "REENTREGA", "RJ", 1, 0, "unidade")
        regs = db.buscar_historico_por_cliente("CLIENTE LENTO", somente_morosidade_cliente=True)
        self.assertEqual(sorted(r["nf_numero"] for r in regs), [1, 2])
        self.app._abrir_relatorio()
        self.app.update()
        rel = [w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel)][-1]

        def achar(widget):
            for f in widget.winfo_children():
                if isinstance(f, tk.Label) and "CLIENTE LENTO" in str(f.cget("text")):
                    return f
                r = achar(f)
                if r:
                    return r
        rotulo = achar(rel)
        self.assertIsNotNone(rotulo)
        self.assertEqual(str(rotulo.cget("cursor")), "hand2")
        antes = len([w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel)])
        rotulo.event_generate("<Button-1>")
        self.app.update()
        depois = [w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel)]
        self.assertEqual(len(depois), antes + 1)
        self.assertIn("CLIENTE LENTO", depois[-1].title())

    def test_aba_sobre(self):
        self.app._abrir_sobre()
        self.app.update()
        janela = [w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel)][-1]
        textos = []

        def coletar(w):
            for f in w.winfo_children():
                try:
                    textos.append(str(f.cget("text")))
                except tk.TclError:
                    pass
                coletar(f)
        coletar(janela)
        self.assertIn("Desenvolvido por Ithalo Willian", textos)
        self.assertIn("Contato: ithalowillian@hotmail.com", textos)

    def test_menu_tem_sobre_e_editar(self):
        barra = self.app.nametowidget(self.app.cget("menu"))
        rotulos = [barra.entrycget(i, "label") for i in range(barra.index("end") + 1)
                   if barra.type(i) in ("cascade", "command")]
        self.assertIn("Sobre", rotulos)
        self.assertIn("Editar", rotulos)

    def test_erro_em_callback_vai_para_log(self):
        registro_erros.instalar()
        caminho = registro_erros.caminho_log()
        self.assertTrue(caminho.startswith(self.pasta))
        with mock.patch.object(registro_erros, "_avisar_usuario") as aviso:
            def falha():
                raise RuntimeError("falha de teste")
            self.erros_tk_original = self.app.report_callback_exception
            del self.app.report_callback_exception   # volta ao tratador instalado (registro_erros)
            self.app.after(10, falha)
            self.app.after(60, self.app.quit)
            self.app.mainloop()
            self.app.report_callback_exception = self.erros_tk_original
            aviso.assert_called_once()
        with open(caminho, encoding="utf-8") as arq:
            conteudo = arq.read()
        self.assertIn("RuntimeError: falha de teste", conteudo)
        self.assertIn("versao", conteudo)


if __name__ == "__main__":
    unittest.main()
