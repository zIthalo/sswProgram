# Auxiliador de Processos Logísticos — SAC

Sistema desktop em Python para apoiar a rotina do setor de SAC de uma transportadora:
cadastro de notas fiscais (NF), acompanhamento de ocorrências, agendamentos,
histórico e relatórios.

## Requisitos

- **Python 3.8** (recomendado para compatibilidade com **Windows 7**; versões do
  CPython a partir da 3.9 não oferecem mais suporte oficial ao Windows 7/8).
  Em Windows 10/11 ou Linux, qualquer Python 3.8+ funciona normalmente.
- Nenhuma biblioteca externa é necessária: o sistema usa apenas `tkinter` (interface
  gráfica) e `sqlite3` (banco de dados), ambos inclusos na biblioteca padrão do Python.
  Isso também é o que garante a portabilidade futura para Linux sem precisar reescrever nada.

## Como executar

```
python main.py
```

Na primeira execução, o sistema cria automaticamente o arquivo `sac_logistica.db`
(SQLite) na mesma pasta do programa, já com as categorias oficiais de ocorrência
e as empresas parceiras padrão (Agex, Risso) cadastradas.

## Gerando um .exe para Windows (opcional)

Caso queira distribuir como um executável único para quem não tem Python instalado:

```
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

O executável ficará em `dist/main.exe`. O arquivo `sac_logistica.db` será criado
ao lado do `.exe` na primeira execução.

## Estrutura dos arquivos

Só o `main.py` fica solto na raiz; o resto está organizado em pastas:

```
main.py                  ponto de entrada (python main.py)
nucleo/                  regras de negócio e dados (sem telas)
    database.py          banco SQLite (notas, tratativas, histórico, cadastros)
    dateutils.py         datas digitadas, dias/horas
    occorrencias.py      tipos de ocorrência, sugestão e busca dinâmica
    tratativas_rapidas.py atalhos E / W / S da "Nova atualização"
    desfazer.py          pilha do "Desfazer última alteração"
    registro_erros.py    erros.log + mensagem amigável
    backup.py, exportacoes.py, comprovante.py, aparencia.py,
    atualizacoes.py, versao.py
interface/               telas e diálogos (Tkinter)
    app.py               janela principal (monta o menu e junta os módulos abaixo)
    nota_block.py        bloco visual de cada nota
    formulario.py        formulário de nova nota
    busca_filtro.py      busca por NF/texto, filtro por ocorrência, setas
    lista_notas.py       lista, rolagem e recarga
    edicao_notas.py      editar/resolver/copiar notas e Desfazer
    relatorios.py        relatório de morosidade e histórico
    manutencao.py        backup, exportação, atualização do sistema, cadastros
    dialogs.py           pop-ups reutilizáveis
atualizador/             atualizador.py + atualizador.spec (gera o atualizador.exe)
testes/                  testes automáticos (ver item 38)
```

## Funcionalidades implementadas

### Cadastro de notas

- Cadastro de NF, cliente/remetente e sigla da unidade ou nome da empresa
  parceira (Agex, Risso — editável em **Cadastros → Empresas parceiras**,
  permitindo incluir/excluir conforme novas parcerias).
- Tipos de ocorrência sugeridos por padrão: REENTREGA, MUDOU-SE, LOCALIZAÇÃO,
  ACOMPANHAR, COMPROVANTE, PRIORIZAR ENTREGA, AGENDAMENTO, DEVOLUÇÃO e
  OUTROS. Ao digitar, o sistema sugere o tipo por prefixo (ex.: "prio" →
  "PRIORIZAR ENTREGA"). Se o texto digitado não corresponder a nenhum tipo
  já cadastrado, o sistema pergunta se o usuário deseja cadastrar aquele
  novo tipo de ocorrência (tanto ao criar quanto ao editar a ocorrência de
  uma nota) — a lista de tipos também pode ser gerenciada diretamente em
  **Cadastros → Tipos de ocorrência**.
- A data de inserção da nota é sempre a data atual do sistema, definida
  automaticamente (não há mais campo de data manual no formulário).
- Sugestão automática de remetente: ao digitar no campo Cliente/Remetente
  (no formulário) ou no campo de busca, o sistema sugere o nome com base
  nos remetentes já cadastrados (prefixo). Pressionar `Enter` ou `Tab` cola
  a sugestão no campo. Ao inserir uma nota com um remetente novo, ele é
  **cadastrado automaticamente** para facilitar a sugestão em notas
  futuras — sem perguntar.
- Verificação de duplicidade (mesma NF + cliente + ocorrência) com aviso e
  destaque da nota já existente.
- Agendamento: ao usar a ocorrência "Agendamento", o sistema pede a data do
  agendamento (`0`=hoje, dia do mês, ou `ddmmaaaa`) e recusa datas iguais ou
  anteriores a hoje. A data agendada é exibida em negrito no bloco da nota
  (`AGENDAMENTO: dd/mm/aaaa`).
- Navegação pelo formulário usando apenas a tecla `Enter`: NF → Cliente →
  Ocorrência → Sigla/Empresa → (Enter na Sigla aciona o botão "Adicionar
  nota", exatamente como um clique). As setas ↑/↓ também navegam entre os
  campos e botões do topo da tela (formulário, busca e filtro), sem
  depender de `Tab`.
- Atalhos de edição de texto (`Ctrl+Z` desfazer, `Ctrl+Y` refazer,
  `Ctrl+Backspace` apaga a palavra anterior, `Ctrl+Delete` apaga a palavra
  seguinte) em todos os campos de texto/combobox editáveis.

### Visualização das notas

- Bloco de cada nota no formato `NF: ... / CLIENTE: ... / OCORRÊNCIA: ... /
  SIGLA UNIDADE: ... / DATA: dd/mm/aaaa HORA: hh:mm / DIAS EM TRATATIVAS:
  ...`, com **CLIENTE**, **OCORRÊNCIA** e **AGENDAMENTO** (quando houver)
  sempre exibidos em **negrito**, seguido das atualizações de tratativa
  (data/hora + texto).
- Clique em qualquer parte do bloco seleciona a nota (destaque azul); clique
  sobre o cabeçalho também copia o número da NF para a área de transferência
  ("Número copiado!"). Duplo clique (ou `Enter` com a nota selecionada) abre
  um campo para adicionar uma nova atualização de tratativa — o texto
  digitado é sempre salvo em **letras maiúsculas**.
- Navegação entre notas com as setas ↑/↓ do teclado; a tecla `Delete` marca
  a nota selecionada como resolvida.
- Menu de contexto (botão direito): marcar como resolvido, editar NF,
  remetente, ocorrência, sigla, e **"Copiar informações da nota"** (copia
  todo o conteúdo do bloco, incluindo as tratativas, para a área de
  transferência).
- Interface responsiva: a lista de notas se reajusta automaticamente à
  largura da janela, quebrando as linhas de forma legível mesmo quando a
  janela é estreitada.

### Busca e filtros

- Busca (`Ctrl+F` foca o campo, funcionando mesmo com o foco em outro campo
  de texto) localiza notas ativas pelo número da NF, pelo nome do
  cliente/remetente ou pela sigla da unidade (busca parcial, sem
  diferenciar maiúsculas/minúsculas). Assim como no cadastro, o sistema
  sugere o nome de um cliente já cadastrado enquanto o usuário digita, e
  `Enter`/`Tab` aceitam a sugestão.
  - Ao buscar por **número de NF**, o sistema localiza e destaca aquela
    nota específica na lista. Se o número não corresponder a nenhuma NF
    ativa, o sistema também procura esse número dentro das **atualizações
    de tratativa** já registradas (ex.: um protocolo ou telefone anotado em
    uma ocorrência) e, se encontrar, filtra a lista mostrando as notas
    correspondentes.
  - Ao buscar por **cliente ou sigla**, o sistema **filtra a lista**,
    mostrando todas as notas correspondentes àquele cliente/sigla,
    independente do número de NF ou do tipo de ocorrência. O filtro é
    removido ao limpar o campo de busca (ou pelo botão "Limpar filtro").
- O filtro "Filtrar por ocorrência" é digitável (agiliza a localização do
  tipo) e mostra **apenas as ocorrências que existem entre as notas ativas
  no momento** — se não houver nenhuma nota de Agendamento, por exemplo,
  essa opção não aparece na lista.
- Ao filtrar por "AGENDAMENTO", as notas são organizadas pela **data do
  agendamento em ordem crescente** (a mais próxima primeiro, a mais
  distante por último) — e não pela data em que a ocorrência foi inserida.

### Resolução de notas e histórico

- Fluxo de "marcar como resolvido": o sistema calcula automaticamente os
  dias e horas que a NF ficou em tratativas (sem perguntar isso ao usuário)
  e pergunta apenas **quem demorou mais para resolver o caso** — Unidade
  (clique ou tecla `U`), Cliente (clique ou tecla `C`) ou Sem morosidade
  (`Enter`). O resultado é salvo no histórico.
- **Aba Histórico** (menu superior): mostra todas as notas tratadas nos
  últimos 60 dias, sempre em **ordem decrescente** (da mais recente para a
  mais antiga), com filtros por nome do cliente, sigla da unidade e número
  de NF (os filtros funcionam em tempo real, conforme o usuário digita).
- O histórico expira automaticamente após 60 dias, e também pode ser
  apagado manualmente a qualquer momento pela tela de Relatório.

### Relatório

- **Notas pendentes de tratativa**: total de notas ainda não marcadas como
  resolvidas, além de um campo para digitar uma sigla/empresa e ver, em
  tempo real, quantas notas pendentes existem para ela (busca parcial, sem
  diferenciar maiúsculas/minúsculas).
- **Unidades com mais ocorrências** (top 5, da maior para a menor).
- **Tempo médio para solução do caso** (em dias e horas).
- **Unidades mais morosas** (top 5, da mais para a menos morosa).
- **Clientes mais morosos** (top 5).
- Cada sigla listada nos rankings "Unidades com mais ocorrências" e
  "Unidades mais morosas" é clicável: um clique abre a lista das notas do
  histórico que embasam aquela posição no ranking (no caso das mais
  morosas, somente as notas em que aquela unidade foi apontada como a mais
  demorada).

### Lógica de datas

- `0` = data atual do sistema.
- `1` a `31` (um ou dois dígitos) = dia informado, considerando mês/ano
  correntes.
- 8 dígitos = data completa `ddmmaaaa`.

## Observações e simplificações assumidas

1. O histórico de 60 dias é limpo automaticamente a cada abertura do
   sistema e a cada abertura das telas de Relatório/Histórico, além de
   poder ser apagado manualmente a qualquer momento.
2. Os "dias e horas em tratativas" salvos no histórico ao marcar uma nota
   como resolvida são sempre calculados automaticamente a partir da
   data/hora de inserção da nota até o momento da resolução.
3. **Correção de travamento (versão anterior)**: um pop-up de alerta
   automático não aguardava corretamente a resposta do usuário antes de
   continuar a verificação, o que podia travar a aplicação quando vários
   alertas disparavam ao mesmo tempo. Toda a lógica de lembretes/alertas
   automáticos foi removida do sistema nesta versão, eliminando de vez essa
   classe de problema.
4. A sigla de unidade aceita tanto siglas de 3 letras quanto o nome de uma
   empresa parceira cadastrada (Agex, Risso, etc.) — o campo é o mesmo, sem
   distinção de formato.
5. **Correção de bloco expandindo**: ao adicionar uma nova nota, o cabeçalho
   (que usa um campo de texto para permitir negrito em CLIENTE/OCORRÊNCIA/
   AGENDAMENTO) podia calcular a altura antes de o bloco ser efetivamente
   posicionado na tela, fazendo-o ocupar um espaço enorme até a janela ser
   redimensionada manualmente. Corrigido recalculando a altura sempre que a
   largura real do bloco é definida, sem depender de ação do usuário.
6. **Correção de barra de rolagem**: ao escolher, aplicar ou limpar o filtro
   por ocorrência, a lista agora sempre volta para o topo automaticamente,
   em vez de permanecer na posição de rolagem anterior (que podia deixar o
   único resultado filtrado fora da área visível).
7. **Correção de lentidão ao inserir notas/tratativas**: a lista de notas
   estava recalculando a geometria de cada bloco individualmente (uma
   operação cara) e consultando o banco de dados uma vez por nota para
   buscar as tratativas, o que deixava o sistema lento conforme a
   quantidade de notas ativas crescia. Agora as tratativas de todas as
   notas visíveis são buscadas em uma única consulta, e o recálculo de
   geometria é feito uma única vez para a lista inteira — a atualização
   volta a ser praticamente instantânea.
8. **Correção do atalho Ctrl+F**: os campos de texto do Tkinter têm um
   atalho padrão de Ctrl+F (mover o cursor) que interceptava o atalho antes
   dele chegar à busca. Agora o Ctrl+F funciona a partir de qualquer campo
   do formulário, não só quando nenhum campo está em foco.
9. **Correção de blocos "se movendo" ao rolar o mouse**: quando um filtro
   deixava poucas notas visíveis, a área rolável do canvas podia ficar
   maior que o conteúdo real (por causa dos ajustes de altura dos
   cabeçalhos acontecerem depois do cálculo de rolagem), fazendo o bloco
   parecer se deslocar ao rolar o mouse mesmo sem haver nada para rolar.
   Corrigido resincronizando a área rolável com o tamanho final da lista.
10. **Cópia de NF no Histórico e no Relatório**: os blocos de nota exibidos
    na aba Histórico e no detalhamento de unidades/clientes do Relatório
    agora também copiam o número da NF para a área de transferência ao
    serem clicados, assim como já acontecia com as notas ativas.
11. **Notas que pareciam "sumir"**: ao inserir uma nova nota ou editar a
    ocorrência de uma nota existente, se um filtro (por ocorrência ou por
    busca) estivesse ativo e não correspondesse à nota recém-alterada, o
    sistema agora limpa esse filtro automaticamente para garantir que a
    nota apareça imediatamente, sem precisar fechar e reabrir o sistema.
12. **Clique não rola mais a tela**: clicar sobre uma nota (para selecioná-la
    ou copiar a NF) não força mais a lista a rolar até ela — a rolagem
    automática continua existindo apenas na busca (Ctrl+F) e na navegação
    por teclado (setas ↑/↓), onde faz sentido trazer a nota para a área
    visível.
13. **Otimizações de velocidade na inserção de notas/tratativas e ao marcar
    como resolvido**: inserir uma nova nota, uma nova atualização de
    tratativa, ou marcar uma nota como resolvida não reconstrói mais a lista
    inteira — o sistema agora só acrescenta o bloco novo (ou remove o bloco
    resolvido) diretamente na tela, sem tocar nos demais (exceto ao inserir
    uma nota de Agendamento com o filtro "AGENDAMENTO" ativo, caso em que a
    lista precisa ser reordenada pela data). O banco de dados também passou
    a usar o modo WAL do SQLite, que acelera a gravação de cada
    nota/tratativa/resolução. Com essas mudanças, essas três ações deixam de
    depender da quantidade de notas já cadastradas — testes isolados do
    banco de dados (sem contar o tempo de desenho da tela, que varia
    conforme o computador) mostraram tempos na casa de 1 a 2 milissegundos,
    mesmo com 150 notas ativas simuladas. Não foi necessário remover nenhuma
    funcionalidade para atingir esse ganho.
14. **Correção de tratativas "invisíveis"**: em alguns blocos, o espaço da
    atualização de tratativa aparecia reservado na tela, mas o texto não era
    desenhado até o usuário redimensionar a janela manualmente — um
    comportamento típico do Tkinter no Windows, em que um widget é criado e
    ocupa espaço, mas não é repintado imediatamente. Corrigido forçando uma
    repintura completa (não apenas o recálculo de geometria) sempre que a
    lista é atualizada, o que resolve o problema sem exigir ação do usuário.
15. **Otimizações de velocidade ao editar campos e ao redimensionar a
    janela**: editar um campo de uma nota (ocorrência, sigla, NF, etc.) não
    reconstrói mais a lista inteira — o sistema agora atualiza somente o
    bloco da nota alterada (exceto com o filtro "AGENDAMENTO" ativo, caso em
    que a lista precisa ser reordenada). Dentro do próprio bloco atualizado,
    agora só o texto do cabeçalho (NF/CLIENTE/OCORRÊNCIA/SIGLA/AGENDAMENTO)
    é reescrito — o separador e as linhas de tratativa já existentes não são
    mais destruídos e recriados, já que nenhum desses campos é afetado por
    uma edição de NF/cliente/ocorrência/sigla, o que preserva o estado
    desses widgets e evita trabalho desnecessário. Essa atualização pontual
    também não força mais a repintura completa do canvas usada apenas para
    blocos recém-criados (ver item 14), já que o bloco editado já está
    desenhado na tela. Ao redimensionar a janela, eventos que alteram só a
    altura (sem mudar a largura útil da lista) agora são ignorados
    imediatamente, e o reajuste de quebra de linha de cada bloco passou a
    rodar uma única vez, depois que o usuário solta o arraste do mouse, em
    vez de a cada evento intermediário durante o arraste. Juntas, essas
    mudanças eliminam o atraso perceptível ao editar um campo ou redimensionar
    a janela com muitas notas ativas, sem alterar nenhum outro comportamento
    do sistema.
16. **Correção de tela "quebrada"/sobreposta ao usar Win+seta ou arrastar
    rapidamente a borda da janela**: o item 15 parou de forçar a repintura
    completa também no único momento em que o reajuste de layout do
    redimensionamento é de fato aplicado (80ms depois do usuário soltar o
    mouse ou do encaixe automático do Windows). Isso não tem custo perceptível
    — acontece uma única vez por redimensionamento, não a cada evento —, mas
    sem essa repintura, um salto brusco de largura (como o atalho Windows+seta
    para encaixar a janela na metade da tela, ou um arraste muito rápido)
    podia deixar a tela com conteúdo sobreposto/desatualizado até alguma
    outra ação forçar um redesenho. Corrigido voltando a forçar a repintura
    completa nesse ponto específico (e só nele), mantendo intacto o ganho de
    desempenho durante o arraste em si.
17. **Correção de texto cortado/deslocado ao encaixar a janela com
    Windows+seta**: mesmo após o item 16, o atalho Windows+seta (que move E
    redimensiona a janela em uma única operação do sistema, encaixando-a em
    metade da tela) podia deixar o conteúdo da lista com as primeiras letras
    de cada linha cortadas, como se a área rolável tivesse deslizado para a
    direita — mesmo o canvas só tendo rolagem vertical configurada (sem barra
    horizontal para o usuário corrigir isso manualmente). Duas correções:
    (1) o redimensionamento agora lê a largura real e atual do canvas
    (`winfo_width()`) em vez de confiar no valor do evento `<Configure>`
    isolado, que podia não refletir ainda a largura final nesse tipo de
    operação combinada de mover+redimensionar; (2) a posição horizontal da
    área rolável é redefinida explicitamente para o início a cada
    redimensionamento, já que este canvas nunca foi projetado para rolar na
    horizontal. Ambas as correções são de custo fixo (não crescem com a
    quantidade de notas ativas), então não afetam o ganho de desempenho dos
    itens 15 e 16.
18. **Atalhos de edição (Ctrl+Z, Ctrl+Y, Ctrl+Backspace, Ctrl+Delete) na tela
    de "Nova atualização"**: essa tela usava o campo de entrada padrão do
    Tkinter (`simpledialog.askstring`), que não tem pilha de desfazer/refazer
    e não garante os atalhos de apagar palavra inteira. Criado um diálogo
    próprio (`CampoTextoComAtalhos`, em `interface/dialogs.py`) baseado num campo de
    texto de uma linha com desfazer/refazer habilitado, com os quatro
    atalhos implementados explicitamente. Visualmente e no uso (Enter
    confirma, Esc cancela) continua se comportando como antes.
19. **Correção de ocorrências "sumindo" ao trocar o filtro e voltar para
    "Todas as ocorrências"**: a causa raiz era reentrância em
    `recarregar_lista()`. Essa função termina chamando `canvas.update()`
    (necessário para o conteúdo pintar corretamente — ver item 14), e
    `update()` processa toda a fila de eventos pendente do Tcl, não só
    geometria. Se o usuário trocasse o filtro rápido o suficiente, um
    segundo evento de troca de filtro podia já estar enfileirado nesse
    momento e ser processado por esse `update()`, reentrando em
    `recarregar_lista()` ANTES da primeira chamada terminar — destruindo e
    recriando os blocos no meio do processo. Combinado com um segundo
    problema (blocos criados fora da área visível não eram repintados ao
    serem rolados para dentro da tela — mesma classe de bug do item 14, só
    que disparada pela rolagem em vez da inserção), isso produzia os blocos
    duplicados/com cabeçalho ausente relatados, que só se resolviam ao
    clicar em "Limpar filtro" (mais uma chamada a `recarregar_lista()`, que
    por acaso rodava depois que a fila de eventos já tinha esvaziado).
    Duas correções: (1) `recarregar_lista()` ganhou uma guarda de
    reentrância — uma chamada que chega enquanto outra já está em andamento
    só marca que é preciso recarregar de novo ao final, em vez de
    destruir/recriar os blocos no meio da execução atual; (2) a rolagem
    (roda do mouse e barra de rolagem) agora força uma repintura completa
    uma única vez, 80ms depois que o usuário para de rolar (mesmo padrão de
    debounce já usado no redimensionamento), garantindo que o conteúdo
    recém-exposto seja realmente desenhado.
20. **Regra de unicidade: Número da NF + Remetente**: o sistema não permite
    mais cadastrar duas Notas Fiscais com o mesmo número para o mesmo
    remetente — vale para o sistema inteiro (nota ativa ou já resolvida),
    não só para notas em aberto. A checagem acontece na tela (antes mesmo
    de pedir ocorrência/sigla, assim que NF e remetente são informados,
    mostrando "Já existe uma Nota Fiscal cadastrada com este número para
    este remetente.") e também no banco de dados, com um índice UNIQUE em
    `(nf_numero, cliente)`, que protege contra duas inserções quase
    simultâneas (concorrência). Se o banco já tiver dados antigos (de antes
    dessa regra existir) que violem essa unicidade, a criação do índice é
    automaticamente pulada sem apagar nem alterar nada — nesse caso a regra
    continua valendo para notas novas através da checagem feita na tela,
    mas sem a proteção extra de concorrência do banco (aplicável apenas a
    quem nunca teve NFs duplicadas cadastradas antes desta versão).

21. **Centralização da janela "Nova atualização"**: ao calcular os atalhos de
    teclado (item 18), a posição da janela de "Nova atualização" (e de
    qualquer outra janela baseada em `CampoTextoComAtalhos`) passou a usar um
    deslocamento fixo (`+60+60` a partir do canto da janela principal), o que
    fazia a janela aparecer deslocada para o canto superior esquerdo em vez
    de centralizada. Corrigido para calcular a posição com base no tamanho
    real da janela de diálogo e no tamanho/posição da janela principal
    (`winfo_width`/`winfo_height`/`winfo_rootx`/`winfo_rooty`), centralizando
    a janela de diálogo sobre a janela principal do sistema, como era antes —
    mantendo o mesmo tamanho da janela.

22. **Atualização automática via GitHub Releases**: o sistema agora verifica
    sozinho, ao abrir (e também sob demanda em Arquivo > Verificar
    atualizações...), se existe uma versão mais nova publicada no
    repositório público do GitHub (`zIthalo/sswProgram`). Se houver, pergunta
    ao usuário se quer atualizar agora; ao confirmar, baixa o `main.exe` novo,
    fecha o sistema, substitui o executável antigo pelo novo e reabre tudo
    automaticamente — sem precisar que o programador vá até o computador do
    usuário. Detalhes técnicos e como publicar uma nova versão estão na seção
    "Como publicar uma atualização", mais abaixo.

23. **Copiar nota(s) sem o histórico de tratativas**: o menu de contexto
    (botão direito) de cada nota ganhou a opção "Copiar informações da nota
    (sem atualizações)", que copia só o cabeçalho (NF/CLIENTE/OCORRÊNCIA/
    SIGLA/DATA/AGENDAMENTO), sem as linhas de tratativa abaixo — a opção
    "Copiar informações da nota" original continua existindo, com as
    tratativas incluídas. Além disso, um botão "Copiar notas filtradas" foi
    adicionado ao lado do filtro de ocorrência: ele copia de uma vez o
    cabeçalho de todas as notas atualmente visíveis na tela (já considerando
    o filtro de ocorrência e a busca por cliente/sigla/NF em uso no momento),
    separadas por linha em branco — pensado para a cobrança diária de uma
    unidade/sigla/empresa inteira de uma vez, sem precisar copiar nota por
    nota.

24. **Backup automático do banco** (`nucleo/backup.py`): ao fechar o sistema (X ou
    Arquivo > Sair) é criada uma cópia datada do `sac_logistica.db` na
    subpasta `backups/`, ao lado do banco. São mantidos os 30 backups
    automáticos mais recentes (os mais antigos são apagados). Antes da cópia
    é feito um `wal_checkpoint`, para que as últimas gravações (o banco usa
    modo WAL) não fiquem de fora. Também há Arquivo > Criar backup agora
    (manual, nunca apagado automaticamente) e um backup "antes_atualizacao"
    feito automaticamente antes de aplicar uma atualização do `.exe`. Falha
    de backup nunca impede o uso ou o fechamento do sistema. Para restaurar:
    feche o sistema e copie o backup desejado por cima de `sac_logistica.db`.
25. **Exportações** (`nucleo/exportacoes.py`): Arquivo > Exportar tudo (salvaguarda)
    cria uma pasta datada com cópia integral do `.db` + `notas.csv`,
    `tratativas.csv` e `historico.csv`. Nas telas Relatório e Histórico há o
    botão de exportar para CSV (separador `;`, UTF-8 com BOM — abre direto no
    Excel em português).
26. **Observação/tag por nota**: nova coluna opcional `observacao` em `notas`
    (migração automática por `ALTER TABLE`, sem mexer nos dados existentes).
    Botão direito > "Editar observação/tag". Aparece no fim do cabeçalho como
    `OBS: ...` e também no comprovante e nas exportações.
27. **Nova nota para o mesmo remetente/sigla**: botão direito na nota preenche
    o formulário de nova nota com Remetente e Sigla, deixando NF e ocorrência
    para digitar. O número da NF não é copiado de propósito: a regra de
    unicidade NF + Remetente (item 20) continua valendo e não é contornada.
28. **Comprovante (impressão/PDF)** (`nucleo/comprovante.py`): botão direito >
    "Gerar comprovante" cria uma página HTML (dados da nota + todas as
    tratativas) em `comprovantes/` e a abre no navegador; use Ctrl+P para
    imprimir ou "Salvar como PDF". Foi feito assim para não adicionar
    biblioteca externa de PDF ao projeto (empacotamento/Windows 7). Todo texto
    é escapado (`html.escape`).
29. **Aparência personalizável** (`nucleo/aparencia.py`, menu "Aparência"): cor da
    fonte, cor de fundo, cor da nota selecionada e quais campos do cabeçalho
    ficam em negrito (NF, remetente, ocorrência, sigla, data/hora, dias,
    agendamento, observação), com pré-visualização. Preferências em
    `config_aparencia.json` (ao lado do banco, separado dos dados).
    "Restaurar padrão de fábrica" apaga o arquivo e volta exatamente ao visual
    original (cor vazia = cor padrão do sistema; negrito padrão: remetente,
    ocorrência e agendamento). O texto das notas e das cópias não muda com a
    aparência. Custo de desempenho desprezível: a configuração fica em memória
    e é aplicada uma vez por bloco (medido: 5000 cabeçalhos em ~0,08 s).
    Arquivo corrompido ou com valores inválidos é ignorado (volta ao padrão).

30. **Unicidade NF + Remetente só entre notas pendentes** (altera o item 20):
    o sistema só impede cadastrar uma NF se já houver uma nota **pendente de
    tratativa** com o mesmo número e remetente. Se a anterior já foi marcada
    como resolvida, a NF pode ser cadastrada de novo. No banco, o índice UNIQUE
    global virou um índice **parcial** (`WHERE resolvido = 0`); a migração
    remove o índice antigo automaticamente, sem apagar nem alterar dados (se
    houver duas pendentes iguais de versões antigas, o índice é pulado e a
    regra segue valendo pela checagem na tela). Editar NF/remetente de uma
    nota para colidir com outra pendente também é bloqueado, com mensagem.
31. **Rolagem do mouse só na janela em foco**: o binding global da roda do
    mouse rolava sempre a lista principal, mesmo com Histórico/Cadastros em
    foco. Agora a rolagem vai somente para a janela que tem o foco (lista
    principal, Histórico, detalhes do Relatório); em janelas sem área rolável
    própria (ex.: Cadastros, que usa a rolagem nativa da sua lista) a lista
    principal não se move.
32. **NF repetida na busca**: ao buscar um número de NF que existe em mais de
    uma nota pendente (remetentes diferentes ou reinserida após resolvida), a
    lista é filtrada mostrando todas as notas com aquele número (ignorando o
    filtro de ocorrência para nenhuma ficar escondida). No Histórico, o filtro
    por NF já mostra todos os registros com o número.

33. **Busca dinâmica ao editar remetente/ocorrência**: "Editar remetente" e
    "Editar ocorrência" abrem uma janela com campo de busca e lista de
    sugestões filtrada a cada tecla (começa com o texto primeiro, depois
    contém). Use ↑/↓ ou clique e Enter; sem resultado, o texto vira novo valor
    (remetente novo é cadastrado; tipo novo pede confirmação, como no cadastro).
34. **Agendamento na edição**: ao alterar a ocorrência para Agendamento o
    sistema pede a data (mesmas regras do cadastro; cancelar/inválida não altera
    nada). Sair de Agendamento limpa a data. Em notas já agendadas, o menu
    ganha "Alterar data do agendamento", que mostra a data atual e só muda a data.

35. **Atalhos na "Nova atualização"**: digitar só `E`/`e` grava "tratando via
    e-mail", `W`/`w` grava "tratando via WhatsApp" e `S`/`s` grava
    "informacoes em sistema" (como todo o texto das tratativas, é salvo em
    maiúsculas). Qualquer outro texto é gravado como digitado.
36. **Registro de erros** (`nucleo/registro_erros.py`): erros inesperados em
    menus/botões vão para `erros.log` (ao lado do banco; recriado ao passar
    de 1 MB) e o usuário vê uma mensagem com o caminho do arquivo.
37. **Desfazer** (menu Editar ou Ctrl+Z na janela principal): desfaz as
    últimas 30 ações da sessão — edições (NF, remetente, ocorrência/data de
    agendamento, sigla, observação), "marcar como resolvido" (a nota volta e
    o registro do histórico é removido), limpeza do histórico e remoção de
    itens em Cadastros. Se o desfazer criar duplicidade de NF pendente, o
    sistema avisa e não altera nada. Dentro de campos de texto, Ctrl+Z
    continua desfazendo a digitação.
38. **Testes automáticos** (`testes/`): rode `sh testes/executar.sh` (Linux,
    usa tela virtual) ou `python -m unittest discover -s testes -t . -v`
    (Windows). Usam um banco temporário e a janela real; rode antes de gerar
    cada `.exe`.
39. **Relatório — clientes mais morosos clicáveis**: clicar em um cliente do
    top 5 abre as notas do histórico em que ele foi apontado como o mais
    moroso, com dias/horas de cada uma.
40. **Menu Sobre**: mostra versão, desenvolvedor e contato.

41. **Atalhos globais** (janela principal): `Ctrl+N` limpa o formulário e leva
    o cursor ao campo da NF; `Ctrl+F` vai para a busca; `F5` recarrega a
    lista a partir do banco. Também aparecem no menu **Editar**.

## Como publicar uma atualização (GitHub Releases)

O sistema verifica atualizações consultando a release mais recente do
repositório público `zIthalo/sswProgram`. Para distribuir uma nova versão
para todos os usuários sem precisar reinstalar manualmente em cada
computador:

1. **Suba a versão**: edite `nucleo/versao.py` e troque o valor de `VERSAO` (ex.:
   de `"1.0.0"` para `"1.1.0"`).
2. **Gere o executável principal**: `pyinstaller --onefile --windowed main.py`
   (ou `pyinstaller main.spec`). O arquivo sai em `dist/main.exe`.
3. **Gere o atualizador** (só precisa ser feito uma vez, a não ser que o
   próprio `atualizador/atualizador.py` mude): `pyinstaller atualizador/atualizador.spec`. O arquivo
   sai em `dist/atualizador.exe`.
4. **Primeira instalação de um computador novo**: copie `main.exe` e
   `atualizador.exe` juntos, na mesma pasta, para o computador do usuário.
   As atualizações seguintes acontecem sozinhas a partir daí — não é
   necessário reenviar o `atualizador.exe` de novo, a menos que ele mesmo
   tenha sido alterado (nesse caso, é a única situação que ainda exige ir
   manualmente ao computador, já que o atualizador não se autoatualiza).
5. **Publique a nova versão no GitHub**: na página do repositório, vá em
   "Releases" → "Draft a new release". Em "Tag", use exatamente o mesmo
   número definido no passo 1, com `v` na frente (ex.: `v1.1.0` para
   `VERSAO = "1.1.0"`). Anexe o `main.exe` gerado no passo 2 como arquivo da
   release (o `atualizador.exe` **não** precisa ser anexado aqui — ele já
   está instalado localmente em cada computador). O texto da release
   (changelog) aparece para o usuário na mensagem de confirmação da
   atualização.
6. Pronto — na próxima vez que cada computador abrir o sistema (ou se o
   usuário clicar em "Verificar atualizações..."), ele vai detectar a nova
   tag, perguntar se quer atualizar e, ao confirmar, baixar e trocar o
   executável sozinho.

**Importante**: a tag no GitHub e o `VERSAO` em `nucleo/versao.py` precisam bater
exatamente (só muda o `v` na frente). Se esquecer de atualizar o
`nucleo/versao.py` antes de gerar o `.exe`, o sistema instalado vai continuar
pensando que está na versão antiga e vai ficar oferecendo a mesma
atualização repetidamente.

## Próximos passos sugeridos

- Empacotar com PyInstaller para gerar um instalador único para os
  atendentes que não tenham Python instalado.
- Se a base de usuários crescer muito, considerar migrar de SQLite para um
  banco cliente/servidor (ex. PostgreSQL) — a camada `nucleo/database.py` foi escrita
  de forma isolada exatamente para facilitar essa troca no futuro, sem
  precisar alterar a interface gráfica.
